GITHUB_WEBSITE = "https://github.com/ivan321pum"
FIVERR_WEBSITE = "https://fiverr.com/codeshark_"