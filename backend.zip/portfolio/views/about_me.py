import reflex as rx
from portfolio.styles.fonts import Font
from portfolio.styles.styles import Size


def about_me() -> rx.Component:
    return rx.box(
        rx.text("ABOUT ME", font_family=Font.TITLE.value, font_size=Size.BIG.value, align="center"),
        rx.flex(
            rx.card(

            ),
        ),
    )
